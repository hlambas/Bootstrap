<?php

abstract class Module {

    function __construct() {
    }

    abstract public function render(); 

}
?>
