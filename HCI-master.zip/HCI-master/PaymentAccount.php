<?php

class PaymentAccount extends Entity {

    function __construct($i = null, $n = null) {
        parent::__construct($i, $n);
    }

}
?>
